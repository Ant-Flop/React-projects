let store = {

}

let rerenderEntireTree = () => {
    console.log('state changed');
}

let state = {
    profilePage: {
        posts: [
            {id: 1, message: "Wtf, Yes of cause", likesCount: 20},
            {id: 2, message: "Hello, my name is Jimmy Pop", likesCount: 30}
        ],
        newPostText: ''
    },
    dialogsPage: {
        dialogs: [
            {id: 1, name: "Thomas"},
            {id: 2, name: "Kristy"},
            {id: 3, name: "Mike"}
        ],
        messages: [
            {id: 1, message: "What`s up nigga ?"},
            {id: 2, message: "WTF is ?"},
            {id: 3, message: "Hello"}
        ]
    },
    sidebar: {}
}



export const addPost = () => {
    let newPost = {
        id: 5,
        message: state.profilePage.newPostText,
        likesCount: 0
    };
    state.profilePage.posts.push(newPost);
    state.profilePage.newPostText = '';
    rerenderEntireTree(state);
}

export const updateNewPostText = (newText) => {
    state.profilePage.newPostText = newText;
    rerenderEntireTree(state);
}

export const subscribe = (observer) => {
    rerenderEntireTree = observer;  // паттерн наблюдатель / publisher-subscriber
}

export default state;

